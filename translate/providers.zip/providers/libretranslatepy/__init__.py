#from libretranslatepy.api import *
# je remplace la ligne precedente pour voir si gimp arrete d'afficher un message derreur au demarrage
#le message est ImportError: No module named libretranslatepy.api
from api import *
